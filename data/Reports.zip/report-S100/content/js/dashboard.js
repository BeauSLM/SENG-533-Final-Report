/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.71308065302843, "KoPercent": 0.2869193469715663};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6385246607178722, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.7899490504863362, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9613246873552571, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.4877257989810097, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.7818901303538175, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9625232774674115, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.49022346368715086, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.5100942126514132, 500, 1500, "Login"], "isController": false}, {"data": [0.933602512337371, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9277703005832212, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9294062646096307, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9614305750350631, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.05990990990990991, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.5072463768115942, 500, 1500, "Logout"], "isController": false}, {"data": [0.2610192837465565, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.15839781520254892, 500, 1500, "List Products"], "isController": false}, {"data": [0.5174652933273622, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34853, 100, 0.2869193469715663, 919.8581757667928, 0, 7839, 706.5, 1908.0, 2561.850000000002, 3951.980000000003, 145.1295226753168, 4516.977375855451, 143.2586416658165], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 2159, 0, 0.0, 603.5345067160728, 61, 4125, 484.0, 901.0, 1017.0, 3340.600000000001, 9.031432228701465, 236.74964325528958, 8.245129761476486], "isController": false}, {"data": ["Add Product to Cart-0", 2159, 0, 0.0, 436.2779064381662, 53, 1424, 443.0, 494.0, 510.0, 891.8000000000002, 9.031016669106728, 8.213488453715517, 8.10845278742183], "isController": false}, {"data": ["Add Product to Cart", 2159, 0, 0.0, 1039.8619731357094, 114, 4576, 935.0, 1350.0, 1524.0, 3780.0000000000005, 9.028712896130074, 244.88975199659384, 16.349031538289438], "isController": false}, {"data": ["Add Product 2 to Cart-1", 2148, 0, 0.0, 620.2271880819372, 58, 4622, 486.0, 902.0, 1102.4499999999991, 3459.0199999999995, 8.997951583647856, 235.87692899739653, 8.21451627239539], "isController": false}, {"data": ["Add Product 2 to Cart-0", 2148, 0, 0.0, 435.19878957169504, 67, 1696, 444.0, 494.0, 511.0, 848.6499999999965, 8.997084743490936, 8.182555929416027, 9.222024951412392], "isController": false}, {"data": ["Add Product 2 to Cart", 2148, 0, 0.0, 1055.4748603351964, 134, 5048, 940.0, 1343.3000000000004, 1643.3999999999978, 3939.6499999999965, 8.994899540204855, 243.9774897195166, 17.43151507969992], "isController": false}, {"data": ["Login", 2229, 0, 0.0, 927.7074921489453, 90, 6506, 907.0, 1010.0, 1071.5, 3586.0999999999995, 9.294897189012923, 94.86025043628472, 10.326703849469787], "isController": false}, {"data": ["Login-0", 2229, 0, 0.0, 443.7685060565278, 47, 1700, 451.0, 508.0, 525.0, 1368.7999999999975, 9.296564150046295, 7.241480202311838, 3.058764359052159], "isController": false}, {"data": ["Login-1", 2229, 0, 0.0, 483.91924629878855, 43, 6023, 450.0, 507.0, 529.0, 3126.199999999999, 9.296758021529774, 87.63761018133684, 7.269943102193435], "isController": false}, {"data": ["Logout-1", 2139, 0, 0.0, 471.7489481065918, 54, 4824, 448.0, 507.0, 530.0, 2268.1999999999994, 8.963104192419703, 82.57854157718577, 6.956658949485638], "isController": false}, {"data": ["Logout-0", 2139, 0, 0.0, 432.3632538569424, 46, 1536, 440.0, 493.0, 510.0, 858.0, 8.961752296998924, 12.160042457296559, 9.037821401787323], "isController": false}, {"data": ["Look at Product", 2220, 100, 4.504504504504505, 2222.8234234234264, 0, 7375, 2120.0, 3379.6000000000004, 4074.449999999998, 5375.3899999999985, 9.26254302701575, 976.9869721041514, 7.035055609158235], "isController": false}, {"data": ["Logout", 2139, 0, 0.0, 904.1636278634882, 100, 5234, 892.0, 994.0, 1045.0, 2713.9999999999995, 8.959725218338324, 94.70470248785263, 15.989813496135882], "isController": false}, {"data": ["List Products with different page", 2178, 0, 0.0, 1718.4164370982533, 151, 6238, 1489.5, 2552.1000000000004, 3030.0999999999995, 4508.270000000003, 9.101127821119798, 1052.401889728481, 7.347325858140662], "isController": false}, {"data": ["List Products", 2197, 0, 0.0, 1972.2776513427411, 202, 7839, 1819.0, 2858.0, 3678.1, 5116.48, 9.157524425622729, 1060.8208890460355, 7.393783645149054], "isController": false}, {"data": ["Home", 2233, 0, 0.0, 905.2995969547688, 82, 4636, 884.0, 998.0, 1083.0, 3861.4999999999964, 9.309674890977162, 82.8961090389939, 1.8910277122297359], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, 100.0, 0.2869193469715663], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34853, 100, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 2220, 100, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
