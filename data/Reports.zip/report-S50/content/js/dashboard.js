/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.85590778097983, "KoPercent": 0.1440922190201729};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.871628242074928, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9960684551341351, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9993061979648473, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.8545328399629972, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9958217270194986, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.999535747446611, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.8709377901578459, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.9321917808219178, 500, 1500, "Login"], "isController": false}, {"data": [0.9988584474885844, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9990867579908675, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9995348837209302, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9990697674418605, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.41098398169336386, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.9509302325581396, 500, 1500, "Logout"], "isController": false}, {"data": [0.5066820276497696, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.4855371900826446, 500, 1500, "List Products"], "isController": false}, {"data": [0.9533879035925421, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34700, 50, 0.1440922190201729, 450.43610951008924, 0, 2816, 316.5, 1024.0, 1215.0, 1561.9800000000032, 144.59237035648061, 4503.10322943361, 143.62772266365604], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 2162, 0, 0.0, 259.23358001850147, 62, 1943, 249.0, 309.70000000000005, 367.6999999999998, 481.3699999999999, 9.048069438283127, 234.80960721773957, 8.267803578005072], "isController": false}, {"data": ["Add Product to Cart-0", 2162, 0, 0.0, 212.0952821461612, 44, 649, 214.0, 257.0, 268.0, 299.0, 9.048637472743176, 8.241812947566451, 8.169113644472672], "isController": false}, {"data": ["Add Product to Cart", 2162, 0, 0.0, 471.3672525439407, 108, 2160, 466.0, 554.7, 592.8499999999999, 723.5899999999992, 9.046252207168381, 243.00208798390335, 16.433103282666092], "isController": false}, {"data": ["Add Product 2 to Cart-1", 2154, 0, 0.0, 256.71402042711156, 64, 1780, 245.0, 308.0, 367.25, 484.0, 9.01704195812978, 234.018716432031, 8.239478580600801], "isController": false}, {"data": ["Add Product 2 to Cart-0", 2154, 0, 0.0, 209.83054781801283, 48, 584, 212.0, 253.0, 267.0, 298.4499999999998, 9.017608198739042, 8.213577218764915, 9.250021455544113], "isController": false}, {"data": ["Add Product 2 to Cart", 2154, 0, 0.0, 466.5738161559889, 113, 2004, 461.0, 554.0, 600.0, 714.8999999999996, 9.015192734273636, 242.1821007656531, 17.48533255686812], "isController": false}, {"data": ["Login", 2190, 0, 0.0, 432.1502283105023, 99, 1199, 434.0, 513.0, 537.4499999999998, 601.2700000000004, 9.152419122287185, 93.38310086389015, 10.214242747021284], "isController": false}, {"data": ["Login-0", 2190, 0, 0.0, 218.68127853881276, 47, 915, 218.0, 263.0, 278.0, 308.0, 9.154332005467518, 7.1784656814438765, 3.011092541048192], "isController": false}, {"data": ["Login-1", 2190, 0, 0.0, 213.42831050228347, 45, 942, 214.5, 258.0, 271.0, 305.09000000000015, 9.15452333776429, 86.22595468040682, 7.205435609266969], "isController": false}, {"data": ["Logout-1", 2150, 0, 0.0, 212.20930232558158, 41, 989, 213.0, 257.0, 268.0, 301.0, 9.001465354825203, 82.9031442981997, 6.997232834414905], "isController": false}, {"data": ["Logout-0", 2150, 0, 0.0, 208.04465116279084, 40, 600, 208.0, 251.0, 266.0, 290.0, 9.001503041670679, 12.23641819727108, 9.084808648717392], "isController": false}, {"data": ["Look at Product", 2185, 50, 2.288329519450801, 1224.8329519450822, 0, 2816, 1227.0, 1601.4, 1723.6999999999998, 1959.2599999999989, 9.127365387025357, 979.6778685865638, 7.139165887777268], "isController": false}, {"data": ["Logout", 2150, 0, 0.0, 420.3032558139532, 91, 1282, 422.0, 500.0, 528.4499999999998, 572.4899999999998, 8.999619085889853, 95.11999742830652, 16.078704906414426], "isController": false}, {"data": ["List Products with different page", 2170, 0, 0.0, 908.5557603686624, 149, 2090, 899.5, 1139.0, 1212.0, 1366.29, 9.07403070953066, 1052.4362535948528, 7.370608163909611], "isController": false}, {"data": ["List Products", 2178, 0, 0.0, 1066.6262626262642, 176, 2639, 1050.0, 1369.2000000000003, 1491.0999999999995, 1710.6800000000003, 9.09056759700988, 1055.427463476516, 7.384549524132995], "isController": false}, {"data": ["Home", 2199, 0, 0.0, 414.38017280582136, 84, 2464, 415.0, 498.0, 524.0, 615.0, 9.18619272206232, 81.79658714820725, 1.8659453966689086], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, 100.0, 0.1440922190201729], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34700, 50, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 2185, 50, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
