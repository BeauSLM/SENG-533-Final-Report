/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.17325375060494, "KoPercent": 0.8267462493950637};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9177488304565252, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9758723088344469, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9974016332590943, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.9729027468448403, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9764397905759162, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9977561705310396, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.9741959611069558, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.8013381369016984, 500, 1500, "Login"], "isController": false}, {"data": [0.975295934122491, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9004117344312919, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9838709677419355, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9984996249062266, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.8072177668106107, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.9786196549137285, 500, 1500, "Logout"], "isController": false}, {"data": [0.9236749116607774, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.6768198244708312, 500, 1500, "List Products"], "isController": false}, {"data": [0.9114770972722593, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 24796, 205, 0.8267462493950637, 389.29327310856723, 37, 25780, 121.0, 691.0, 2300.0, 7348.780000000035, 103.48871665811079, 3162.9001957616515, 94.47539623817305], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 1347, 17, 1.2620638455827766, 122.23904974016338, 52, 4452, 84.0, 126.0, 178.79999999999973, 1285.5999999999954, 5.664185694461966, 137.86544405197426, 5.171658342006223], "isController": false}, {"data": ["Add Product to Cart-0", 1347, 0, 0.0, 64.2635486265776, 37, 536, 55.0, 71.0, 83.0, 483.52, 5.664781209916521, 5.153076177008642, 5.089784528302879], "isController": false}, {"data": ["Add Product to Cart", 1347, 17, 1.2620638455827766, 186.55011135857487, 99, 4944, 141.0, 187.4000000000001, 242.5999999999999, 1542.52, 5.66318551031734, 142.9927243359316, 10.259095926773792], "isController": false}, {"data": ["Add Product 2 to Cart-1", 1337, 20, 1.4958863126402393, 117.59685863874354, 45, 4609, 83.0, 117.0, 156.0999999999999, 958.8599999999997, 5.622111676919907, 136.637828004697, 5.135668069916867], "isController": false}, {"data": ["Add Product 2 to Cart-0", 1337, 0, 0.0, 63.671652954375645, 37, 1028, 56.0, 73.0, 82.0, 397.27999999998974, 5.6225372487836065, 5.1186646250625545, 5.765531069827539], "isController": false}, {"data": ["Add Product 2 to Cart", 1337, 20, 1.4958863126402393, 181.30815258040354, 99, 5081, 141.0, 182.0, 222.0, 1442.2399999999998, 5.621118926395715, 141.7310739524517, 10.89883789173355], "isController": false}, {"data": ["Login", 1943, 17, 0.8749356664951107, 482.68296448790494, 93, 8908, 138.0, 988.6000000000001, 1678.199999999999, 4619.199999999991, 8.130727706406661, 83.07813791349332, 7.967931872986149], "isController": false}, {"data": ["Login-0", 1943, 0, 0.0, 169.04477611940314, 45, 1637, 74.0, 402.0, 495.39999999999986, 981.0799999999977, 8.132225040389073, 5.247031900044365, 2.673479118534609], "isController": false}, {"data": ["Login-1", 1943, 17, 0.8749356664951107, 313.6119402985079, 40, 8809, 67.0, 676.0, 1008.1999999999996, 4181.159999999991, 8.132531381190958, 77.84933794345945, 5.296119605605712], "isController": false}, {"data": ["Logout-1", 1333, 18, 1.350337584396099, 84.23855963990995, 40, 8878, 59.0, 75.0, 84.0, 474.28000000000065, 5.605574455737829, 51.2438460698426, 4.357458268327453], "isController": false}, {"data": ["Logout-0", 1333, 0, 0.0, 60.54013503375846, 37, 1016, 53.0, 68.0, 76.29999999999995, 373.1200000000026, 5.6056687482915954, 7.620205954708888, 5.658083084957632], "isController": false}, {"data": ["Look at Product", 1621, 14, 0.863664404688464, 853.5811227637254, 134, 9475, 257.0, 2918.0, 4071.7999999999984, 6923.919999999991, 6.78290924459062, 689.9967494092153, 4.933364441717612], "isController": false}, {"data": ["Logout", 1333, 18, 1.350337584396099, 144.83045761440366, 83, 8960, 114.0, 136.0, 151.0, 958.1600000000021, 5.60441962934311, 58.85179705762714, 10.013382857696932], "isController": false}, {"data": ["List Products with different page", 1415, 14, 0.9893992932862191, 381.22190812720817, 92, 5457, 226.0, 319.0, 1640.4000000000015, 3897.2, 5.921815297953103, 658.9701418162291, 4.67258429693614], "isController": false}, {"data": ["List Products", 1937, 16, 0.8260196179659267, 2053.4367578729994, 99, 25780, 335.0, 7011.0, 8497.199999999999, 9845.679999999998, 8.102500606537216, 899.8670536435109, 5.478839073388912], "isController": false}, {"data": ["Home", 1943, 17, 0.8749356664951107, 259.06021616057626, 76, 8961, 122.0, 619.0, 938.0, 1159.1599999999994, 8.130489545018976, 72.00332122050449, 1.6515056888319797], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500", 205, 100.0, 0.8267462493950637], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 24796, 205, "500", 205, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Add Product to Cart-1", 1347, 17, "500", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Add Product to Cart", 1347, 17, "500", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Add Product 2 to Cart-1", 1337, 20, "500", 20, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Add Product 2 to Cart", 1337, 20, "500", 20, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Login", 1943, 17, "500", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Login-1", 1943, 17, "500", 17, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Logout-1", 1333, 18, "500", 18, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 1621, 14, "500", 14, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Logout", 1333, 18, "500", 18, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["List Products with different page", 1415, 14, "500", 14, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["List Products", 1937, 16, "500", 16, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Home", 1943, 17, "500", 17, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
