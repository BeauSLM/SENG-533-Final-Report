/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.41983581353523, "KoPercent": 0.5801641864647695};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.629246076639689, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.6646975425330813, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9267485822306238, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.4829867674858223, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.6645962732919255, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9285714285714286, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.49331103678929766, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.5892143808255659, 500, 1500, "Login"], "isController": false}, {"data": [0.9090102086107412, 500, 1500, "Login-0"], "isController": false}, {"data": [0.867953839325344, 500, 1500, "Login-1"], "isController": false}, {"data": [0.8662175168431184, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9345524542829644, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.1478999106344951, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.5818094321462945, 500, 1500, "Logout"], "isController": false}, {"data": [0.25220622387366465, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.20109439124487005, 500, 1500, "List Products"], "isController": false}, {"data": [0.5899074482150727, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34473, 200, 0.5801641864647695, 1116.13358280393, 0, 21955, 957.0, 3778.9000000000015, 4882.0, 8081.880000000019, 144.09861556982344, 4436.693823229125, 111.78308428768936], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 2116, 0, 0.0, 899.9952741020783, 55, 7475, 509.0, 2195.7999999999997, 3531.1499999999996, 4743.909999999994, 8.88538027411986, 230.2402167254896, 7.564205342933267], "isController": false}, {"data": ["Add Product to Cart-0", 2116, 0, 0.0, 399.0425330812851, 39, 1948, 457.0, 509.0, 532.0, 1220.3199999999997, 8.886872963074959, 7.176777105540015, 4.547653349481739], "isController": false}, {"data": ["Add Product to Cart", 2116, 0, 0.0, 1299.0718336483942, 97, 7932, 982.0, 2740.3, 4024.1499999999996, 5240.959999999992, 8.88377619265535, 237.37292760651295, 12.108908422006659], "isController": false}, {"data": ["Add Product 2 to Cart-1", 2093, 0, 0.0, 877.5355948399432, 51, 7232, 512.0, 2124.800000000002, 3400.0999999999995, 4462.979999999996, 8.788836959305964, 227.658012662035, 7.479077040895596], "isController": false}, {"data": ["Add Product 2 to Cart-0", 2093, 0, 0.0, 393.06354515050145, 39, 1908, 457.0, 508.60000000000014, 533.3, 1194.4199999999996, 8.78939057985621, 7.093238228232296, 8.464575118213734], "isController": false}, {"data": ["Add Product 2 to Cart", 2093, 0, 0.0, 1270.6435738174866, 93, 9083, 986.0, 2674.4000000000033, 3896.2, 5091.419999999996, 8.78691828124016, 234.69955600322217, 15.93963847897731], "isController": false}, {"data": ["Login", 2253, 0, 0.0, 927.2769640479363, 83, 8879, 930.0, 1126.6000000000001, 2230.399999999998, 4445.540000000002, 9.44432334546186, 98.14093703365248, 6.955868885345579], "isController": false}, {"data": ["Login-0", 2253, 0, 0.0, 399.1034176653358, 38, 3112, 458.0, 513.0, 534.0, 1648.38, 9.446976590115266, 3.7329666541224125, 3.115660601746831], "isController": false}, {"data": ["Login-1", 2253, 0, 0.0, 528.1407012871729, 40, 7970, 462.0, 540.6000000000001, 1342.4999999999932, 3834.500000000001, 9.446184420713685, 94.42762281769242, 3.8418402515733163], "isController": false}, {"data": ["Logout-1", 2078, 0, 0.0, 507.21703561116385, 43, 5116, 463.0, 547.0, 1465.1999999999962, 3015.1000000000004, 8.726765721197054, 82.51278482464576, 6.302116853566299], "isController": false}, {"data": ["Logout-0", 2078, 0, 0.0, 387.89412897016325, 37, 1851, 451.0, 507.0, 525.0, 1195.21, 8.726692423987904, 10.186631215353604, 8.258613369834537], "isController": false}, {"data": ["Look at Product", 2238, 200, 8.936550491510276, 2746.28596961573, 0, 17551, 2278.0, 5950.9000000000015, 7256.399999999998, 10736.640000000016, 9.371427614305873, 934.2332912781969, 3.4493395797304145], "isController": false}, {"data": ["Logout", 2078, 0, 0.0, 895.1568816169387, 84, 5924, 923.5, 1195.6000000000035, 2035.1999999999998, 3489.63, 8.725043562236264, 92.68120807790818, 14.557926129206644], "isController": false}, {"data": ["List Products with different page", 2153, 0, 0.0, 2540.0891778913187, 122, 18543, 1901.0, 5371.4000000000015, 6725.799999999999, 10935.760000000004, 9.035285033237091, 1043.2207059773782, 3.822690891641627], "isController": false}, {"data": ["List Products", 2193, 0, 0.0, 2737.5540355677144, 164, 17186, 2192.0, 5391.4000000000015, 6745.499999999998, 10221.839999999993, 9.1746957456689, 1061.157333298121, 3.8974660158685004], "isController": false}, {"data": ["Home", 2269, 0, 0.0, 944.5495813133542, 76, 21955, 924.0, 1093.0, 2812.5, 4793.700000000002, 9.488443669422455, 84.4879193142519, 1.9273401203514362], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, 100.0, 0.5801641864647695], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34473, 200, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 2238, 200, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
