/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.69441388583303, "KoPercent": 0.30558611416697223};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7723230656398973, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.932971907343519, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9889107934943322, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.6720059142434697, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9361386138613862, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9891089108910891, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.6725247524752476, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.6844753234307619, 500, 1500, "Login"], "isController": false}, {"data": [0.9789171058936272, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9808337326305702, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9818407960199005, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9893034825870647, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.3002403846153846, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.6925373134328359, 500, 1500, "Logout"], "isController": false}, {"data": [0.48409980430528377, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.40082444228903974, 500, 1500, "List Products"], "isController": false}, {"data": [0.6904761904761905, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 32724, 100, 0.30558611416697223, 596.3417063928594, 0, 6725, 525.0, 1608.0, 2063.0, 3516.9900000000016, 137.3330759352364, 4279.738115414456, 134.94841950661402], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 2029, 0, 0.0, 368.6209955643177, 56, 4632, 327.0, 517.0, 783.0, 2283.700000000009, 8.55266485693571, 224.94486305303582, 7.79631012867988], "isController": false}, {"data": ["Add Product to Cart-0", 2029, 0, 0.0, 283.3893543617544, 38, 1120, 289.0, 454.0, 481.5, 579.9000000000003, 8.55331382947331, 7.759394180669259, 7.604358122064936], "isController": false}, {"data": ["Add Product to Cart", 2029, 0, 0.0, 652.0591424346961, 95, 5072, 619.0, 984.0, 1202.5, 2744.30000000001, 8.551078894133514, 232.66051711058665, 15.397235564259525], "isController": false}, {"data": ["Add Product 2 to Cart-1", 2020, 0, 0.0, 372.4806930693069, 58, 5109, 330.0, 512.9000000000001, 767.4999999999982, 2505.6899999999923, 8.51422550052687, 223.94457570468916, 7.7611959957850365], "isController": false}, {"data": ["Add Product 2 to Cart-0", 2020, 0, 0.0, 283.17326732673223, 38, 1301, 292.0, 452.0, 479.0, 529.3699999999999, 8.515302251074951, 7.724781452870753, 8.716670410115084], "isController": false}, {"data": ["Add Product 2 to Cart", 2020, 0, 0.0, 655.703960396041, 99, 5537, 624.0, 974.0, 1200.9499999999998, 2999.2299999999914, 8.512359777835838, 231.61761486286463, 16.473153638349025], "isController": false}, {"data": ["Login", 2087, 0, 0.0, 598.8251078102543, 83, 3987, 600.0, 938.0, 983.0, 1668.319999999996, 8.761728835617877, 89.45610558707152, 9.660599279214509], "isController": false}, {"data": ["Login-0", 2087, 0, 0.0, 298.26353617633004, 40, 1539, 300.0, 468.0, 497.0, 800.9599999999991, 8.763458017703277, 6.750123118029545, 2.8840021160685794], "isController": false}, {"data": ["Login-1", 2087, 0, 0.0, 300.52755150934297, 43, 3515, 299.0, 464.20000000000005, 490.5999999999999, 618.079999999999, 8.763752414546065, 82.72641618375746, 6.778731457860922], "isController": false}, {"data": ["Logout-1", 2010, 0, 0.0, 295.6089552238807, 40, 2664, 296.5, 462.0, 486.4499999999998, 638.7199999999939, 8.478007794705674, 78.15641192836716, 6.5738666200587135], "isController": false}, {"data": ["Logout-0", 2010, 0, 0.0, 283.59701492537306, 40, 1193, 293.0, 452.0, 475.0, 740.4799999999705, 8.478401167572857, 11.467492344130289, 8.538546308784635], "isController": false}, {"data": ["Look at Product", 2080, 100, 4.8076923076923075, 1468.619230769232, 0, 6725, 1442.5, 2600.9, 3070.8499999999995, 4857.660000000001, 8.75207230558197, 924.7701750979875, 6.551517339254307], "isController": false}, {"data": ["Logout", 2010, 0, 0.0, 579.2373134328357, 83, 3090, 589.0, 916.9000000000001, 957.0, 1248.7499999999905, 8.476577655572612, 89.6082538170957, 15.109467547833622], "isController": false}, {"data": ["List Products with different page", 2044, 0, 0.0, 1152.0978473581224, 142, 5350, 1111.0, 1933.5, 2378.75, 3642.949999999999, 8.609904760300083, 997.1521146907027, 6.875246648866264], "isController": false}, {"data": ["List Products", 2062, 0, 0.0, 1330.390397672161, 162, 6442, 1263.5, 2236.3, 2827.5499999999997, 4575.849999999999, 8.66980326862515, 1005.4408857550025, 6.925001090557819], "isController": false}, {"data": ["Home", 2100, 0, 0.0, 590.0042857142863, 78, 4020, 580.5, 926.0, 960.0, 2213.869999999997, 8.817601612361438, 78.51454248194491, 1.791075327510917], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, 100.0, 0.30558611416697223], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 32724, 100, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 2080, 100, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 100, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
