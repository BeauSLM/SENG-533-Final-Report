/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.83902124919511, "KoPercent": 0.16097875080489377};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9194140373470702, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.999224405377456, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.999482936918304, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.9278697001034126, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9987026466009341, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9997405293201869, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.9372080954852102, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.9661405295315683, 500, 1500, "Login"], "isController": false}, {"data": [0.9997454175152749, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9997454175152749, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9992195629552549, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9997398543184183, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.5895408163265307, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.9703433922996878, 500, 1500, "Logout"], "isController": false}, {"data": [0.6942724458204335, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.6572745901639344, 500, 1500, "List Products"], "isController": false}, {"data": [0.9773996952767903, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 31060, 50, 0.16097875080489377, 310.9522858982615, 0, 2298, 281.0, 838.0, 1039.0, 1398.9800000000032, 131.33636655785398, 4071.863185052243, 130.41768953865247], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 1934, 0, 0.0, 188.03567735263698, 55, 1236, 184.0, 290.5, 311.25, 431.25000000000045, 8.205937636571157, 213.07868795824265, 7.498369764683919], "isController": false}, {"data": ["Add Product to Cart-0", 1934, 0, 0.0, 149.9968976215098, 38, 591, 148.0, 244.5, 269.0, 300.0, 8.206529579998811, 7.474868099874398, 7.410331915719705], "isController": false}, {"data": ["Add Product to Cart", 1934, 0, 0.0, 338.07600827301, 99, 1467, 339.0, 531.0, 575.0, 662.9500000000003, 8.204301531413057, 220.50904288672422, 14.905194767318543], "isController": false}, {"data": ["Add Product 2 to Cart-1", 1927, 0, 0.0, 185.92267773741594, 57, 1732, 183.0, 282.0, 310.0, 414.0, 8.17668774133322, 212.3014387835745, 7.4716458328913316], "isController": false}, {"data": ["Add Product 2 to Cart-0", 1927, 0, 0.0, 149.35080435910723, 36, 542, 150.0, 241.0, 266.0, 297.0, 8.177034711024357, 7.44800672844352, 8.387990610148094], "isController": false}, {"data": ["Add Product 2 to Cart", 1927, 0, 0.0, 335.31395952257344, 93, 1923, 342.0, 520.4000000000001, 570.1999999999998, 637.9200000000003, 8.174918653832284, 219.7015851101514, 15.85584924815778], "isController": false}, {"data": ["Login", 1964, 0, 0.0, 311.3151731160897, 90, 1624, 319.0, 481.0, 520.0, 589.3499999999999, 8.33177784188288, 85.0102370781083, 9.299499560396905], "isController": false}, {"data": ["Login-0", 1964, 0, 0.0, 157.702647657841, 44, 859, 160.0, 242.0, 266.0, 297.3499999999999, 8.334040566918443, 6.535451630527031, 2.7421573320673853], "isController": false}, {"data": ["Login-1", 1964, 0, 0.0, 153.57892057026493, 41, 1416, 155.5, 240.0, 259.75, 297.3499999999999, 8.333616212362946, 78.49387535960997, 6.55953374817543], "isController": false}, {"data": ["Logout-1", 1922, 0, 0.0, 152.6795005202915, 42, 1367, 157.0, 235.0, 258.0, 296.53999999999996, 8.190119868923993, 75.43068406623259, 6.36430383315294], "isController": false}, {"data": ["Logout-0", 1922, 0, 0.0, 145.94120707596232, 35, 557, 149.0, 233.0, 257.0, 291.0, 8.190224570673713, 11.133586525759577, 8.266961318021051], "isController": false}, {"data": ["Look at Product", 1960, 50, 2.5510204081632653, 794.9520408163274, 0, 2251, 801.0, 1297.9, 1448.6499999999987, 1756.0, 8.310366758532965, 884.8339574610452, 6.482751881492474], "isController": false}, {"data": ["Logout", 1922, 0, 0.0, 298.6706555671179, 81, 1594, 310.0, 463.0, 508.0, 565.77, 8.18858455075687, 86.54790096957186, 14.628416714330449], "isController": false}, {"data": ["List Products with different page", 1938, 0, 0.0, 611.406088751291, 149, 2298, 606.5, 997.1000000000001, 1074.0, 1312.4399999999996, 8.217400706408132, 947.0191086102501, 6.675669134607638], "isController": false}, {"data": ["List Products", 1952, 0, 0.0, 698.790471311476, 160, 2106, 680.0, 1133.7, 1300.35, 1602.8200000000002, 8.267753221120044, 953.6391825044578, 6.71674705789545], "isController": false}, {"data": ["Home", 1969, 0, 0.0, 294.83900457084815, 77, 1775, 301.0, 457.0, 495.5, 563.5999999999999, 8.354158622942752, 74.38790851952345, 1.6969384702852464], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, 100.0, 0.16097875080489377], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 31060, 50, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 1960, 50, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 50, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
