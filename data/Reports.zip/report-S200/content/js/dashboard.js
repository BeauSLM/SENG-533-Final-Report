/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.40100882723833, "KoPercent": 0.5989911727616646};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4532557606328098, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.3769266697804764, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.8274170948155067, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.22585160989267383, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.3775894538606403, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.826271186440678, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.22339924670433145, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.4334358523725835, 500, 1500, "Login"], "isController": false}, {"data": [0.7772407732864675, 500, 1500, "Login-0"], "isController": false}, {"data": [0.7119947275922671, 500, 1500, "Login-1"], "isController": false}, {"data": [0.7131303520456708, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.8553758325404377, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.007947019867549669, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.4241198858230257, 500, 1500, "Logout"], "isController": false}, {"data": [0.028604118993135013, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.023370786516853932, 500, 1500, "List Products"], "isController": false}, {"data": [0.4479440069991251, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34892, 209, 0.5989911727616646, 1771.3305915396097, 0, 27289, 992.0, 4382.9000000000015, 5872.950000000001, 9586.990000000002, 145.18189345616292, 4492.378636978432, 122.15727273460158], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 2141, 0, 0.0, 1560.4857543204141, 166, 17439, 1015.0, 3608.0, 4092.699999999997, 5959.159999999996, 8.960295970168618, 232.83130351694754, 7.807321757961104], "isController": false}, {"data": ["Add Product to Cart-0", 2141, 0, 0.0, 522.8766931340496, 115, 2322, 491.0, 534.0, 873.6999999999982, 1290.6399999999994, 8.966112199943046, 7.536717650698527, 5.708842676348895], "isController": false}, {"data": ["Add Product to Cart", 2143, 2, 0.09332711152589827, 2081.458236117589, 0, 17930, 1523.0, 4108.200000000001, 4641.799999999999, 6446.399999999998, 8.964351747274721, 240.2650945324984, 13.50596092919919], "isController": false}, {"data": ["Add Product 2 to Cart-1", 2124, 0, 0.0, 1544.9350282485873, 109, 17002, 1016.5, 3519.0, 3979.5, 5681.75, 8.89424888821889, 231.11773881047796, 7.7501046220572345], "isController": false}, {"data": ["Add Product 2 to Cart-0", 2124, 0, 0.0, 523.7278719397361, 132, 1936, 491.0, 535.0, 986.0, 1256.5, 8.892684887459806, 7.476324181592477, 8.742149492040962], "isController": false}, {"data": ["Add Product 2 to Cart", 2124, 0, 0.0, 2068.7071563088502, 246, 17486, 1529.0, 4050.0, 4549.5, 6222.0, 8.888628498014286, 238.44460640408107, 16.483369000489628], "isController": false}, {"data": ["Login", 2276, 0, 0.0, 1363.1388400702997, 80, 25178, 1000.0, 2506.300000000004, 3592.0, 5301.030000000001, 9.515288845037919, 98.32867424036557, 8.115780888107562], "isController": false}, {"data": ["Login-0", 2276, 0, 0.0, 540.1511423550079, 37, 3535, 494.0, 543.0, 726.6500000000046, 1736.0, 9.52839469993511, 4.901900982249388, 3.1401350527494607], "isController": false}, {"data": ["Login-1", 2276, 0, 0.0, 822.951230228472, 42, 24692, 499.0, 1564.1000000000013, 3041.4500000000003, 4786.23, 9.516760956191957, 93.44797069759613, 4.980735392963618], "isController": false}, {"data": ["Logout-1", 2102, 0, 0.0, 737.1584205518564, 99, 6033, 499.0, 1482.7, 2608.0, 3431.229999999988, 8.819925815276683, 82.68463277670314, 6.527095368332605], "isController": false}, {"data": ["Logout-0", 2102, 0, 0.0, 515.1194100856324, 128, 1965, 487.0, 530.0, 795.8499999999981, 1254.7899999999986, 8.814932546056136, 10.841355327330904, 8.522638292903602], "isController": false}, {"data": ["Look at Product", 2265, 201, 8.874172185430464, 4350.76203090507, 0, 27289, 3907.0, 7649.8, 9337.899999999994, 13292.14000000001, 9.430741302066853, 946.3539330016613, 4.582653265159969], "isController": false}, {"data": ["Logout", 2102, 0, 0.0, 1252.3177925784978, 250, 6522, 992.0, 2091.0000000000005, 3120.7, 4030.9399999999796, 8.811274407062433, 93.44038419116106, 15.03979443678267], "isController": false}, {"data": ["List Products with different page", 2185, 3, 0.13729977116704806, 4401.47826086957, 0, 25241, 3815.0, 7674.800000000001, 9491.599999999995, 13321.819999999985, 9.109366596765653, 1055.699804745313, 4.959272161348353], "isController": false}, {"data": ["List Products", 2225, 3, 0.1348314606741573, 4543.368539325838, 0, 24186, 3908.0, 7622.8, 9283.4, 14068.539999999985, 9.27052431585614, 1076.4350213391324, 5.044171867448168], "isController": false}, {"data": ["Home", 2286, 0, 0.0, 1332.5297462817143, 77, 15099, 984.0, 2533.6000000000004, 4332.85, 5746.930000000007, 9.542255578838398, 84.96707653110208, 1.93827066445155], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, 95.69377990430623, 0.5731972945087699], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 9, 4.30622009569378, 0.025793878252894645], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34892, 209, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 9, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Add Product to Cart", 2143, 2, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Look at Product", 2265, 201, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in query at index 126: http://a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080/tools.descartes.teastore.webui/product?id=${product_id}", 200, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["List Products with different page", 2185, 3, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["List Products", 2225, 3, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: a4174e42464ac412ea57dff0e91e015c-384586860.us-west-2.elb.amazonaws.com:8080 failed to respond", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
