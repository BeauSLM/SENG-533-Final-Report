/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9613446614439664, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.988, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.996, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.9667692307692307, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9931163954943679, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9974968710888611, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.9759073842302879, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.9523681377825619, 500, 1500, "Login"], "isController": false}, {"data": [0.988697524219591, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9919268030139935, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9993634627625716, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9990451941438574, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.8492809734513275, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.9866327180140039, 500, 1500, "Logout"], "isController": false}, {"data": [0.907948568088837, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.8262872628726288, 500, 1500, "List Products"], "isController": false}, {"data": [0.9898341359015517, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 27189, 0, 0.0, 225.35724006031847, 37, 9007, 117.0, 347.0, 774.0, 3527.9900000000016, 113.49747032009216, 3583.852323249835, 108.36415369736095], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 1625, 0, 0.0, 122.68307692307677, 53, 5691, 88.0, 144.4000000000001, 360.6999999999998, 526.0, 6.815131689313874, 170.22706102033007, 6.203023100675223], "isController": false}, {"data": ["Add Product to Cart-0", 1625, 0, 0.0, 86.13907692307693, 38, 1445, 58.0, 103.40000000000009, 368.6999999999998, 491.0, 6.815503277732807, 6.167338266796546, 6.0011161697291], "isController": false}, {"data": ["Add Product to Cart", 1625, 0, 0.0, 208.8504615384615, 98, 5900, 150.0, 234.4000000000001, 725.4999999999991, 1031.74, 6.813702880623926, 176.3570815993333, 12.201253524780913], "isController": false}, {"data": ["Add Product 2 to Cart-1", 1598, 0, 0.0, 113.55444305381722, 51, 4735, 86.0, 131.0, 240.14999999999986, 507.0799999999999, 6.702148630001972, 167.3184210002055, 6.107088174880783], "isController": false}, {"data": ["Add Product 2 to Cart-0", 1598, 0, 0.0, 77.39799749687114, 38, 1075, 58.0, 89.0, 178.24999999999977, 474.0, 6.702682750868245, 6.076698372984581, 6.8584046799762595], "isController": false}, {"data": ["Add Product 2 to Cart", 1598, 0, 0.0, 190.9799749687111, 99, 5810, 147.0, 205.0, 432.5499999999995, 996.1199999999999, 6.700715357972509, 173.35755423889435, 12.962173737168843], "isController": false}, {"data": ["Login", 1858, 0, 0.0, 218.36652314316498, 92, 3233, 136.0, 472.2000000000003, 650.05, 1023.5600000000013, 7.786503951923158, 79.68787324300766, 8.199444954907007], "isController": false}, {"data": ["Login-0", 1858, 0, 0.0, 108.93864370290629, 44, 775, 71.0, 214.10000000000014, 323.0, 596.4100000000001, 7.788168522888749, 5.608990837741598, 2.55833774552851], "isController": false}, {"data": ["Login-1", 1858, 0, 0.0, 109.40312163616804, 42, 2586, 65.0, 228.10000000000014, 393.04999999999995, 526.0, 7.788331754428619, 74.09747076362748, 5.6429783256029875], "isController": false}, {"data": ["Logout-1", 1571, 0, 0.0, 72.67536600891161, 40, 1106, 60.0, 83.0, 108.39999999999986, 417.55999999999995, 6.589765100671141, 60.72978794174706, 5.113492620071309], "isController": false}, {"data": ["Logout-0", 1571, 0, 0.0, 68.06747294716722, 37, 1008, 55.0, 79.0, 103.0, 445.67999999999984, 6.589571614927414, 8.92681357405613, 6.640540618301896], "isController": false}, {"data": ["Look at Product", 1808, 0, 0.0, 584.465707964603, 103, 7596, 223.5, 1922.9000000000012, 2788.95, 4529.580000000004, 7.573472738849234, 805.7159815511795, 5.647591741437954], "isController": false}, {"data": ["Logout", 1571, 0, 0.0, 140.78739656269892, 81, 1495, 116.0, 153.79999999999995, 208.39999999999986, 871.56, 6.588383308869783, 69.64225745046132, 11.751763505189768], "isController": false}, {"data": ["List Products with different page", 1711, 0, 0.0, 381.0713033313852, 95, 8246, 200.0, 1005.7999999999997, 1774.3999999999999, 2863.199999999998, 7.172921487741893, 828.1528227133431, 5.553988378588556], "isController": false}, {"data": ["List Products", 1845, 0, 0.0, 851.9663956639566, 136, 9007, 265.0, 2960.6000000000017, 4495.299999999998, 6972.859999999998, 7.727845794920983, 896.1517505651902, 5.8088589856626465], "isController": false}, {"data": ["Home", 1869, 0, 0.0, 162.5997859818084, 79, 1034, 120.0, 308.0, 390.5, 787.3999999999992, 7.801933577117667, 69.47073276968642, 1.5847677578520263], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 27189, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
