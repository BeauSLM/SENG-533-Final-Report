/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.97193298363736, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9911054637865311, 500, 1500, "Add Product to Cart-1"], "isController": false}, {"data": [0.9974587039390089, 500, 1500, "Add Product to Cart-0"], "isController": false}, {"data": [0.954574332909784, 500, 1500, "Add Product to Cart"], "isController": false}, {"data": [0.9958199356913183, 500, 1500, "Add Product 2 to Cart-1"], "isController": false}, {"data": [0.9980707395498393, 500, 1500, "Add Product 2 to Cart-0"], "isController": false}, {"data": [0.9639871382636656, 500, 1500, "Add Product 2 to Cart"], "isController": false}, {"data": [0.97083583884546, 500, 1500, "Login"], "isController": false}, {"data": [0.9936861094407697, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9921828021647625, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9983755685510072, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9990253411306043, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.912, 500, 1500, "Look at Product"], "isController": false}, {"data": [0.9808317089018843, 500, 1500, "Logout"], "isController": false}, {"data": [0.9411027568922306, 500, 1500, "List Products with different page"], "isController": false}, {"data": [0.8839879154078549, 500, 1500, "List Products"], "isController": false}, {"data": [0.9836016696481813, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 25546, 0, 0.0, 193.52822359664955, 37, 5187, 134.0, 334.0, 523.9500000000007, 1422.9900000000016, 106.61180133296051, 3322.738967452487, 104.04817652362938], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Product to Cart-1", 1574, 0, 0.0, 154.3227445997459, 53, 2674, 113.0, 265.5, 369.5, 560.5, 6.800869336029485, 170.34552002454188, 6.1956977223676875], "isController": false}, {"data": ["Add Product to Cart-0", 1574, 0, 0.0, 100.8113087674713, 39, 2553, 68.0, 190.5, 330.75, 448.5, 6.788345092897683, 6.152135691158332, 6.010655678823728], "isController": false}, {"data": ["Add Product to Cart", 1574, 0, 0.0, 255.18932655654393, 104, 3774, 183.0, 443.0, 719.0, 1008.25, 6.786003759463328, 176.1231866557914, 12.19073752522117], "isController": false}, {"data": ["Add Product 2 to Cart-1", 1555, 0, 0.0, 143.86302250803885, 54, 912, 116.0, 252.4000000000001, 339.39999999999964, 491.7600000000002, 6.760516842599516, 169.271896174167, 6.160174523503121], "isController": false}, {"data": ["Add Product 2 to Cart-0", 1555, 0, 0.0, 94.12797427652735, 37, 1116, 68.0, 170.80000000000018, 290.0, 418.32000000000016, 6.760428667695585, 6.128875936080256, 6.917369009901528], "isController": false}, {"data": ["Add Product 2 to Cart", 1555, 0, 0.0, 238.04244372990323, 102, 1874, 185.0, 415.8000000000002, 609.1999999999989, 842.0, 6.758460027294617, 175.34748820529202, 13.073655024350014], "isController": false}, {"data": ["Login", 1663, 0, 0.0, 224.69693325315683, 91, 2982, 158.0, 364.40000000000055, 504.1999999999998, 955.0, 6.9512077880278715, 71.02334772967617, 7.553148995356108], "isController": false}, {"data": ["Login-0", 1663, 0, 0.0, 112.05111244738421, 47, 2161, 82.0, 191.60000000000014, 251.0, 529.2399999999991, 6.9525155313260365, 5.246452343599756, 2.2831926242401566], "isController": false}, {"data": ["Login-1", 1663, 0, 0.0, 112.60372820204434, 41, 2654, 75.0, 174.0, 225.0, 492.1599999999994, 7.013859014263903, 66.37073818704609, 5.317887811732925], "isController": false}, {"data": ["Logout-1", 1539, 0, 0.0, 92.471085120208, 39, 954, 72.0, 151.0, 225.0, 391.7999999999997, 6.698847832994546, 61.75575583619162, 5.191813655105096], "isController": false}, {"data": ["Logout-0", 1539, 0, 0.0, 87.32813515269652, 37, 818, 66.0, 147.0, 222.0, 389.1999999999998, 6.698148107849324, 9.058882173089897, 6.744382507670881], "isController": false}, {"data": ["Look at Product", 1625, 0, 0.0, 365.27753846153786, 84, 5066, 199.0, 805.2000000000003, 1364.2999999999965, 3130.220000000001, 6.94032177467231, 742.0769678681787, 5.380388525886333], "isController": false}, {"data": ["Logout", 1539, 0, 0.0, 179.85834957764754, 82, 1772, 140.0, 298.0, 431.0, 772.9999999999986, 6.696865658002951, 70.79463016706265, 11.933368613990314], "isController": false}, {"data": ["List Products with different page", 1596, 0, 0.0, 280.07456140350854, 78, 3674, 183.5, 543.1999999999998, 933.7499999999993, 1449.5899999999986, 6.87753167284323, 799.7916672277644, 5.44139648689994], "isController": false}, {"data": ["List Products", 1655, 0, 0.0, 450.7570996978853, 145, 5187, 252.0, 924.4000000000001, 1713.7999999999938, 3391.600000000002, 6.978617179626654, 813.7800692617213, 5.475434107938757], "isController": false}, {"data": ["Home", 1677, 0, 0.0, 186.659511031604, 84, 4132, 140.0, 340.20000000000005, 440.0999999999999, 761.22, 7.006827164929932, 62.3908692283507, 1.4232617678763924], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 25546, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
